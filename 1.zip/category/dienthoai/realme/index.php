<?php
    $title = 'Điện thoại Realme';
	$baseUrl = '../../../';
    $UrlCartView = '../../..';
    $product_type = 'Realme';
    $product_type_url = '../';
    include_once('../dienthoai-main.php');
?>
<style> 
    .product-type a:nth-child(6) span {
        background-color: #ddd;
    }
</style>