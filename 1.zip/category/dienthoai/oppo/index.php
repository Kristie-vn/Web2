<?php
    $title = 'Điện thoại OPPO';
	$baseUrl = '../../../';
    $UrlCartView = '../../..';
    $product_type = 'OPPO';
    $product_type_url = '../';
    include_once('../dienthoai-main.php');
?>
<style> 
    .product-type a:nth-child(3) span {
        background-color: #ddd;
    }
</style>