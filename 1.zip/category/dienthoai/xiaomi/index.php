<?php
    $title = 'Điện thoại Xiaomi';
	$baseUrl = '../../../';
    $UrlCartView = '../../..';
    $product_type = 'Xiaomi';
    $product_type_url = '../';
    include_once('../dienthoai-main.php');
?>
<style> 
    .product-type a:nth-child(5) span {
        background-color: #ddd;
    }
</style>