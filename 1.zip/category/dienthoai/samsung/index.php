<?php
    $title = 'Điện thoại SAMSUNG';
	$baseUrl = '../../../';
    $UrlCartView = '../../..';
    $product_type = 'SAMSUNG';
    $product_type_url = '../';
    include_once('../dienthoai-main.php');
?>
<style> 
    .product-type a:nth-child(2) span {
        background-color: #ddd;
    }
</style>