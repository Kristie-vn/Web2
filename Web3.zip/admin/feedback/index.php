<?php
	$title = 'Quản lý phản hồi';
	$baseUrl = '../';
	require_once($baseUrl.'layouts/header.php');
?>
<style> 
	.nav-item:nth-child(6) {
		background-color: #c1c1c1;
	}
</style>
<div class="row">
	<div class="col-md-12">
		<h1>Quản lý phản hồi</h1>
	</div>
</div>

<?php
	require_once($baseUrl.'layouts/footer.php');
?>