<div class="login">
    <a href="<?=$baseUrl?>authen/register" class="tag-a" style="color: #000;"><span class="">ĐĂNG KÝ</span></a>
</div>