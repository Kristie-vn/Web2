<?php
    header('Location: ../');
?>