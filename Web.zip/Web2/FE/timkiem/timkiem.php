<div class="masthead-search">
    <div class="masthead-search-box">
        <form action="FE/timkiem/index.php" class="header-search-form">
            <input type="text"  name = "tk" value="<?php echo isset($_GET['tk']) ? $_GET['tk'] : ''; ?>" placeholder="Nhập tên sản phẩm..." class="header-search-input">
            <button type="submit" class="header-search-icon" value ="TimKiem">
            <i class="fas fa-search"></i>
            </button>
        </form>
    </div>
</div>


