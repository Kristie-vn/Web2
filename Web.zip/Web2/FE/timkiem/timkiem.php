<div class="masthead-search">
    <div class="masthead-search-box">
        <form action="search.php" method = "get" class="header-search-form">
            <input type="text" placeholder="Tìm kiếm nước hoa" class="header-search-input">
            <button type="submit" class="header-search-icon" value= "search">
                <i class="fas fa-search"></i>
            </button>
        </form>
    </div>
</div>

