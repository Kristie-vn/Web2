<?php
  require_once ('database/dbhelper.php');


  $sql = "SELECT * FROM product";
  if (isset($_GET['txtName']))
  {
    $sql = $sql . " WHERE title like '%" . $_GET['txtName'] . "%'";
  }
  $result = executeQuery($sql);
  // Hien thi ket qua
  echo '<table width="80%" align="center" border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111">';
  echo "<tr>";
  echo "<th>STT</th>";
  echo "<th>Tên</th>";   	   
  echo "<th>Giá</th>";   
  echo "<th>Hình ảnh</th>";
  echo "</tr>";
  if ($result->num_rows > 0) {
    // output data of each row
    $i = 1;
    while ($row = $result->fetch_array()){
      echo "<tr>";
      echo "<td>" . $i . "</td>";
      echo "<td>" . $row['title'] . "</td>";
      echo "<td>" . $row['price'] . "</td>";
      echo "<td><img src='images/" . $row["thumnail"] . "'></td>";
      echo "</tr>";
      $i++;
    }
  }
  echo "</table>";
?>