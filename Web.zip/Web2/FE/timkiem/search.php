<?php
    if (!empty($_REQUEST['tk'])) {
        $tk = $_GET['tk'];    
        $sql = "SELECT * FROM product WHERE title LIKE '%".$tk."%'"; 
        $data = executeResult($sql);
        foreach($data as $item) {
            if(isset($_SESSION['email'])) {
                $Url_cart = 'cart/cart_home.php?add_to_cart='.$item['id'];
            }else {
                $Url_cart = 'authen/login';
                $message = "Bạn hãy đăng nhập để thêm sản phẩm vào giỏ hàng của mình!!!";
            }
            echo '
            <div class="col l-4 c-6 product-selling-items shop-cuahang-items">
                <div class="product-selling-box-img">
                    <a href="'.$baseUrl.'category/sanpham/sp.php?sp='.$item['id'].'"><img src="'.$baseUrl.$item['thumnail'].'"   alt=""></a>
                </div>
                <div class="product-selling-info">
                    <div class="product-selling-name">
                        <span>'.$item['title'].'</span>
                    </div>
                    <div class="product-selling-price">
                        <div class="product-selling-price-old">'.number_format($item['price']).'<sup>đ</sup></div>
                        <div class="product-selling-price-now">'.number_format($item['discount']).'<sup>đ</sup></div>
                    </div>
                    <div class="btn-add-cart-box">
                        <a  href="'.$baseUrl.$Url_cart.'"  class="tag-a link-add-cart"><span class="btn-add-cart">THÊM VÀO GIỎ HÀNG</span></a>
                    </div>
                </div>
            </div>';

        } 
    }
?>

