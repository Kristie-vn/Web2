<div class="section-bg-phone">
    <div class="section-bg">
    <img src="category/ads/chanel_home.jpg">
    </div>
    <div class="section-description">
        <span class="big-img-birth">CHÀO MỨNG ĐẾN VỚI DGC STORE</span>
        <span class="big-img-name-product">THẾ GIỚI CỦA NHỮNG MÙI HƯƠNG</span>
        <span class="big-img-time-sale"></span>        
    </div>
    <!--<a href="#main-product-a" class="tag-a"><i class="fas fa-chevron-down bg-down"></i></a>-->
</div>