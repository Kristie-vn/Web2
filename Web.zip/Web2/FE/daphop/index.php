<?php
    $title = "ĐẬP HỘP VÀ NHẬN QUÀ";
    $baseUrl = '../../';
    require_once('../layouts_FE/header.php')
?>
<link rel="stylesheet" href="../layouts_FE/css/footer.css">
<div class="baohang">
    <div class="bao-hanh-title">
        <span>ĐẬP HỘP VÀ NHẬN QUÀ</span>
    </div>
    <div class="grid wide">
        <div class="bao-hanh-main">
            <span style="font-weight: 600;font-size:27px;">CHIA SẺ NHƯ THẾ NÀO?</span>
            <span style="margin-top: 20px;">Chụp hình, viết cảm nhận về sản phẩm và chia sẻ lên Facebook, Instagram ở chế độ public. Copy đường dẫn vừa chia sẻ và truy cập https:// www.lixibox.com/loves/ để dán vào, sau đó bấm Xác nhận.</span>
            <span style="margin-top: 20px;">Lưu ý:Lixibox chỉ xác nhận những chia sẻ ở chế độ public Chỉ chấp nhận những liên kết chia sẻ có cả hình ảnh và cảm nhận của bạn. Số lần tối đa chia sẻ dựa trên số đơn hàng bạn đã thanh toán.</span>
            <span style="font-weight: 600;font-size:27px; margin-top:30px;">CHIA SẺ CẢM NHẬN SẼ ĐƯỢC ƯU ĐÃI GÌ?</span>
            <span style="margin-top: 20px;">Với mỗi hình chụp sản phẩm kèm #Lixibox, nhận ngay 100 Lixicoin. Chụp ảnh selfie với sản phẩm hoặc box kèm #Lixibox và #LixiSelfie, nhận ngay 200 Lixicoin. Quay clip đập hộp kèm #Lixibox nhận ngay 200 Lixicoin.</span>
            <span style="margin-top: 20px;">Lixicoin có thể được sử dụng để đổi quà tại Đây. Tìm hiểu thêm về Lixicoin.</span>
        </div>
    </div>
    </div>
<?php
    require_once('../layouts_FE/footer.php')
?>