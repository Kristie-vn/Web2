<?php
define('HOST','localhost');
define('DATABASE','website_ban_hang');
define('USERNAME','root');
define('PASSWORD','');
define('PRIVATE_KEY','');
?>
