<div class="login__mobile wide-nav-items">
    <a href="<?=$baseUrl?>authen/login" class="tag-a" style="color: #000;">
        <span class="wide-nav-items-span" style="text-transform: uppercase;">ĐĂNG NHẬP</span>
    </a>
</div>