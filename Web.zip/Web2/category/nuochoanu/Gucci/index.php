<?php
    $title = 'NƯỚC HOA NỮ';
	  $baseUrl = '../../../';
    $UrlCartView = '../../..';
    $product_type = 'GUCCI';
    $product_type_url = '../';
    include_once('../nuochoanu-main.php');
?>
<style> 
    .product-type a:nth-child(1) span {
        background-color: #ddd;
    }
</style>